"""
Gesture Tracker - بروجكت بسيط للتعرف على جستشر اليد وربطه بصورة
==================================================================
الفكرة: نفتح الكاميرا، نتابع إيد المستخدم، ولو عمل "Thumbs Up"
نعرض صورة معينة جنب صورة الكاميرا. غير كده، نعرض صورة "عادي/Neutral".

الخطوة الجاية بعد ما تفهم الكود ده: تقدر تضيف دالة classify جديدة
لأي جستشر تاني (Peace, Fist, OK sign...) بنفس الأسلوب بالظبط.
"""

import cv2
import mediapipe as mp
import numpy as np
import os

# ------------------------------------------------------------------
# 1) خريطة: اسم الجستشر -> اسم ملف الصورة اللي هتتعرض معاه
#    غيّر أسماء الملفات دي لأسماء الصور بتاعتك إنت
# ------------------------------------------------------------------
IMAGE_PATHS = {
    "THUMBS_UP": "images/thumbs_up.jpg",
    "THINKING": "images/thinking.jpg",
    "NEUTRAL": "images/neutral.jpg",
}

# ------------------------------------------------------------------
# 2) إعداد MediaPipe
#    mp_hands: هو اللي بيرجعلنا 21 نقطة (landmark) على اليد
#    mp_face_mesh: بيرجعلنا نقط كتير جداً (468 نقطة) على الوش، إحنا
#                  هنستخدم نقطة واحدة بس منهم (طرف الأنف)
#    mp_drawing: أدوات لرسم النقاط والخطوط بين المفاصل على الشاشة
# ------------------------------------------------------------------
mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands
mp_face_mesh = mp.solutions.face_mesh

hands = mp_hands.Hands(
    static_image_mode=False,       # False = بنشتغل على فيديو مباشر (مش صورة ثابتة)
    max_num_hands=1,               # أقصى عدد إيدين نتابعهم في نفس الوقت
    min_detection_confidence=0.7,  # نسبة الثقة عشان نعتبر إن ده "إيد فعلاً"
    min_tracking_confidence=0.6    # نسبة الثقة عشان نكمل نتابع نفس الإيد بين الفريمات
)

face_mesh = mp_face_mesh.FaceMesh(
    max_num_faces=1,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)


def load_and_resize_image(path, target_height):
    """
    بتفتح صورة من الهارد وتظبط ارتفاعها عشان يبقى نفس ارتفاع فريم الكاميرا
    (عشان لما نحط الصورتين جنب بعض، الأبعاد تتظبط صح)
    """
    full_path = os.path.join(os.getcwd(), path)
    img = cv2.imread(full_path)

    if img is None:
        print(f"خطأ: مقدرتش أفتح الصورة {path}. اتأكد إن الملف موجود في المكان الصح.")
        return None

    ratio = target_height / img.shape[0]
    target_width = int(img.shape[1] * ratio)
    return cv2.resize(img, (target_width, target_height))


def classify_gesture(hand_landmarks):
    """
    ==========================================================
    قلب الموضوع: هنا بنفهم "المستخدم بيعمل إيه بإيده"
    ==========================================================
    MediaPipe بترجعلنا 21 نقطة على الإيد (landmarks)، كل نقطة
    ليها إحداثي x و y (بين 0 و 1، نسبة لحجم الفريم).

    مهم جداً: المحور y بيزيد كل ما نزلنا لتحت الشاشة.
    يعني لو y صغير -> النقطة فوق. لو y كبير -> النقطة تحت.

    عشان نعرف "الصباع طالع فوق ولا لأ"، بنقارن مكان طرف الصباع
    (TIP) بمكان مفصل نص الصباع (PIP) بتاع صباع تاني كمرجع.
    """

    # نجيب إحداثي y بس (الارتفاع) لكل نقطة مهمة لينا
    y_thumb_tip = hand_landmarks.landmark[mp_hands.HandLandmark.THUMB_TIP].y
    y_index_tip = hand_landmarks.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP].y
    y_middle_tip = hand_landmarks.landmark[mp_hands.HandLandmark.MIDDLE_FINGER_TIP].y
    y_ring_tip = hand_landmarks.landmark[mp_hands.HandLandmark.RING_FINGER_TIP].y
    y_pinky_tip = hand_landmarks.landmark[mp_hands.HandLandmark.PINKY_TIP].y

    # المفصل الأوسط لصباع الوسطى، هنستخدمه كـ "خط مرجعي"
    y_middle_pip = hand_landmarks.landmark[mp_hands.HandLandmark.MIDDLE_FINGER_PIP].y

    # شرط 1: الإبهام طالع فوق الخط المرجعي (يعني y بتاعه أصغر)
    is_thumb_up = y_thumb_tip < y_middle_pip

    # شرط 2: باقي الصوابع كلها تحت الخط المرجعي (يعني مقفولة/نازلة)
    are_other_fingers_down = (
        y_index_tip > y_middle_pip and
        y_middle_tip > y_middle_pip and
        y_ring_tip > y_middle_pip and
        y_pinky_tip > y_middle_pip
    )

    if is_thumb_up and are_other_fingers_down:
        return "THUMBS_UP"

    # لو مفيش أي شرط اتحقق -> نرجع الحالة الافتراضية
    return "NEUTRAL"


def check_thinking_gesture(hand_landmarks, face_landmarks, frame_width, frame_height):
    """
    ==========================================================
    جستشر التفكير: صباعك السبابة قريب من بقك/أنفك، والصوابع
    التانية مقفولة (زي حركة "خليني أفكر شوية")
    ==========================================================
    الفرق عن classify_gesture: هنا مش بنقارن y بس، إحنا محتاجين
    نحسب "المسافة الفعلية" بين نقطتين في الفضاء (x, y).
    عشان كده بنحول الإحداثيات (اللي أصلاً نسبة من 0 إلى 1)
    لبيكسلات حقيقية بضربها في عرض/طول الفريم.
    """
    if not hand_landmarks or not face_landmarks:
        return False

    # إحداثيات طرف الصباع السبابة، محولة لبيكسلات
    index_tip = hand_landmarks.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP]
    index_x = int(index_tip.x * frame_width)
    index_y = int(index_tip.y * frame_height)

    # النقطة رقم 4 في face_mesh هي طرف الأنف تقريباً
    nose_tip = face_landmarks.landmark[4]
    nose_x = int(nose_tip.x * frame_width)
    nose_y = int(nose_tip.y * frame_height)

    # قانون المسافة الإقليدية العادي: الجذر التربيعي لمجموع مربعات الفروق
    distance = np.sqrt((index_x - nose_x) ** 2 + (index_y - nose_y) ** 2)

    MAX_DISTANCE = 50  # بالبيكسل - جرب تكبرها/تصغرها لو مش حساسة كفاية

    # نتأكد كمان إن الوسطى مقفولة، عشان منلخبطش الجستشر ده بجستشر تاني
    y_middle_pip = hand_landmarks.landmark[mp_hands.HandLandmark.MIDDLE_FINGER_PIP].y
    y_middle_tip = hand_landmarks.landmark[mp_hands.HandLandmark.MIDDLE_FINGER_TIP].y
    is_middle_finger_down = y_middle_tip > y_middle_pip

    if distance < MAX_DISTANCE and is_middle_finger_down:
        return True

    return False


# ====================================================================
# 3) البرنامج الرئيسي - اللوب اللي بيشتغل طول الوقت لحد ما تدوس 'q'
# ====================================================================
CAMERA_INDEX = 0  # 0 = الكاميرا الافتراضية في جهازك
cap = cv2.VideoCapture(CAMERA_INDEX)

print("Gesture Tracker شغال. دوس 'q' عشان تقفل.")

while cap.isOpened():
    success, frame = cap.read()
    if not success:
        break

    # نعكس الفريم أفقياً عشان يبقى زي المراية (طبيعي أكتر للمستخدم)
    frame = cv2.flip(frame, 1)
    frame_height, frame_width, _ = frame.shape

    # MediaPipe بيتوقع الصورة بصيغة RGB، وOpenCV بيقرأها BGR افتراضياً
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # هنا بيتم التحليل الفعلي: كل موديل بيرجعلنا نتيجة فيها الـ landmarks
    hand_results = hands.process(rgb_frame)
    face_results = face_mesh.process(rgb_frame)

    current_gesture = "NEUTRAL"
    hand_landmarks_data = None
    face_landmarks_data = None

    if hand_results.multi_hand_landmarks:
        # multi_hand_landmarks ممكن يحتوي أكتر من إيد، إحنا بناخد أول واحدة بس
        hand_landmarks_data = hand_results.multi_hand_landmarks[0]

    if face_results.multi_face_landmarks:
        face_landmarks_data = face_results.multi_face_landmarks[0]

    if hand_landmarks_data:
        # بنفحص THINKING الأول لأنه محتاج شرطين (إيد + وش)، أدق من THUMBS_UP
        if face_landmarks_data and check_thinking_gesture(
            hand_landmarks_data, face_landmarks_data, frame_width, frame_height
        ):
            current_gesture = "THINKING"
        else:
            # لو مش THINKING، نجرب باقي الجستشرز اللي بتفحص اليد بس
            current_gesture = classify_gesture(hand_landmarks_data)

        # نرسم شكل اليد (النقاط والخطوط) على الفريم عشان نشوفه بصرياً
        mp_drawing.draw_landmarks(
            frame,
            hand_landmarks_data,
            mp_hands.HAND_CONNECTIONS,
            mp_drawing.DrawingSpec(color=(121, 22, 76), thickness=2, circle_radius=4),
            mp_drawing.DrawingSpec(color=(250, 44, 250), thickness=2, circle_radius=2)
        )

    # نجيب الصورة المناسبة للجستشر الحالي ونظبط حجمها
    gesture_image = load_and_resize_image(IMAGE_PATHS[current_gesture], frame_height)

    if gesture_image is not None:
        # نلزّق صورة الكاميرا مع صورة الجستشر جنب بعض (أفقياً، axis=1)
        output_frame = np.concatenate((frame, gesture_image), axis=1)

        cv2.putText(
            output_frame,
            f"Gesture: {current_gesture.replace('_', ' ')}",
            (frame_width + 10, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 255, 0),
            2
        )
    else:
        output_frame = frame
        cv2.putText(
            output_frame,
            "LOAD IMAGE FAILED - Check images/ folder!",
            (10, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 0, 255),
            2
        )

    cv2.imshow('Gesture & Image Pairing', output_frame)

    key = cv2.waitKey(5)
    if key == ord('q') or key == 27:  # 27 = زر Esc
        break

# نقفل كل حاجة بشكل نضيف قبل ما نخرج
hands.close()
face_mesh.close()
cap.release()
cv2.destroyAllWindows()
